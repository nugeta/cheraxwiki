
import __ASTRO_IMAGE_IMPORT_Z1SsV7j from "../../assets/cherax-logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fdocs%2Findex.mdx";
export default new Map([["../../assets/cherax-logo.png?astroContentImageFlag=&importer=src%2Fcontent%2Fdocs%2Findex.mdx", __ASTRO_IMAGE_IMPORT_Z1SsV7j]]);
		